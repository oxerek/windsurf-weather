@NonNullApi
package com.sonalake.windsurfweather.adapters;

import org.springframework.lang.NonNullApi;